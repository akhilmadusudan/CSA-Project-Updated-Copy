import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Goal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Goal extends Actor
{
    int lala = 1;
    /**
     * Act - do whatever the Goal wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Goal()
    {
        getImage().scale(getImage().getWidth()/2, getImage().getHeight()/2);
    }

    public void act() 
    {
        finish();
    }    

    public void finish()
    {
        if(isTouching(Player.class))
        {
            String q=Greenfoot.ask("Congrats, You have passed and finished the game. Would you like to play again? (yes)");
            if (q.contains("yes")){
                Greenfoot.setWorld(new MyWorld());
            }
        }
    }
}
