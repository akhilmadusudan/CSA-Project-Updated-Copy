import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Blockers here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Blockers extends Actor
{
    int sideScreen;
    int bottomScreen;
    public int speed = 5;
    /**
     * Act - do whatever the Blockers wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.Questions()
    }

    public void Q1()
    {

        if(hitPlayer() == true)
        {
            speed = 0;
            String q=Greenfoot.ask("Was the coronavirus originated from Hong Kong?(yes/no)");
            if (q.contains("no")){
                getWorld().removeObject(this);
                speed = 5;
            }
            else 
            {
                String r =Greenfoot.ask("The answer was wrong, please restart the game!(restart)");
                if (r.contains("restart")){
                    Greenfoot.setWorld(new MyWorld());

                }
            }
        } 
    } 

    public void Q2()
    {

        if(hitPlayer() == true)
        {
            speed = 0;
            String q=Greenfoot.ask("Is coughing a way to transmit the virus to another person?(yes/no)");
            if (q.contains("yes")){
                getWorld().removeObject(this);
                speed = 5;
            }
            else
            {
                String r =Greenfoot.ask("The answer was wrong, please restart the game!(restart)");
                if (r.contains("restart")){
                    Greenfoot.setWorld(new MyWorld());

                }

            }
        }
    }    

    public void Q3()
    {

        if(hitPlayer() == true)
        {
            speed = 0;
            String q=Greenfoot.ask("Is wearing a mask the only way to prevent Covid-19?(yes/no)");
            if (q.contains("no")){
                getWorld().removeObject(this);
                speed = 5;
            }
            else
            {
                String r =Greenfoot.ask("The answer was wrong, please restart the game!(restart)");
                if (r.contains("restart")){
                    Greenfoot.setWorld(new MyWorld());

                }
            }

        }
    }

    public void Q4()
    {

        if(hitPlayer() == true)
        {
            speed = 0;
            String q=Greenfoot.ask("Has Covid-19 surpassed 1 million deaths?(yes/no)");
            if (q.contains("yes")){
                getWorld().removeObject(this);
                speed = 5;
            }
            else 
            {
                String r =Greenfoot.ask("The answer was wrong, please restart the game!(restart)");
                if (r.contains("restart")){
                    Greenfoot.setWorld(new MyWorld());

                }
            }
        }
    }

    public void moveAround()
    {
        int x = getX();
        int y = getY();
        if(Greenfoot.isKeyDown("d"))
        {
            setLocation(x + speed, y);
        }
        if(Greenfoot.isKeyDown("a"))
        {
            setLocation(x - speed, y);
        }
        if(Greenfoot.isKeyDown("w"))
        {
            setLocation(x, y - speed);
        }
        if(Greenfoot.isKeyDown("s"))
        {
            setLocation(x, y + speed);
        }
    }

    public boolean hitPlayer()
    {
        if(isTouching(Player.class))
        {
            return(true);
        }
        else
        {
            return(false);
        }
    }

    public void addedToWorld(World in)
    {
        sideScreen = in.getWidth() - 1;
        bottomScreen = in.getHeight() - 1;
    }

    public void randomMovement()
    {
        move(10);
        if(Greenfoot.getRandomNumber(20)==1)
        {
            setRotation(Greenfoot.getRandomNumber(360));
        }
        int x = getX();
        int y = getY();

        if(x <= 0 || y <= 0 || x>= sideScreen || y>= bottomScreen)
        {
            turn(180);
        }
    }

}
